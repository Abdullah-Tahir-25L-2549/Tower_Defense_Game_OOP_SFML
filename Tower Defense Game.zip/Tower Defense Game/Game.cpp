#include "Game.h"
#include <cmath>
#include <string>
#include <iostream>
#include <iomanip>

void Tower::triggerFireSound()
{
    if (owningGame != nullptr && soundIndex >= 0)
    {
        owningGame->playSoundForTower(soundIndex);
    }
}

void Game::showFlash(const std::string& message)
{
    hudToastMessage = message;
    hudToastSecondsLeft = 2.f;
}

void Game::logGameStart()
{
    std::cout << "\n";
    std::cout << "======================================\n";
    std::cout << "      TOWER DEFENSE  -  STARTED\n";
    std::cout << "======================================\n";
    std::cout << "  Starting Gold : " << gold << "\n";
    std::cout << "  Starting Lives: " << lives << "\n";
    std::cout << "  Total Waves   : " << waveManager.getTotalWaves() << "\n";
    std::cout << "--------------------------------------\n\n";
}

void Game::logKill(const std::string& enemyName, int reward)
{
    totalKills++;
    std::cout << "[KILL  #" << std::setw(3) << totalKills << "]  "
        << std::setw(14) << std::left << enemyName
        << "  +" << reward << " gold"
        << "   Score: " << score << "\n";
}

void Game::logLifeLost(int damage, int livesRemaining)
{
    std::cout << "[LIFE LOST]  -" << damage
        << " lives  |  Lives remaining: " << livesRemaining << "\n";
}

void Game::logWave(int waveNum)
{
    std::cout << "\n-- Wave " << waveNum << " started --\n\n";
}

void Game::logWin()
{
    std::cout << "\n======================================\n";
    std::cout << "          *** VICTORY! ***\n";
    std::cout << "======================================\n";
    std::cout << "  Final Score: " << score << "\n";
    std::cout << "  Total Kills: " << totalKills << "\n";
    std::cout << "  Lives Left : " << lives << "\n";
    std::cout << "  Gold Left  : " << gold << "\n";
    std::cout << "--------------------------------------\n\n";
}

void Game::logLoss()
{
    std::cout << "\n======================================\n";
    std::cout << "          *** GAME OVER ***\n";
    std::cout << "======================================\n";
    std::cout << "  Final Score : " << score << "\n";
    std::cout << "  Total Kills : " << totalKills << "\n";
    std::cout << "  Wave Reached: " << waveManager.getCurrentWave()
        << "/" << waveManager.getTotalWaves() << "\n";
    std::cout << "--------------------------------------\n\n";
}

void Game::loadAssets()
{
    textureLoadOk[0] = texEnemyBasic.loadFromFile("assets/basic_enemy.png");
    textureLoadOk[1] = texEnemyFast.loadFromFile("assets/fast_enemy.png");
    textureLoadOk[2] = texEnemyTank.loadFromFile("assets/tank_enemy.png");
    textureLoadOk[3] = texEnemyFlying.loadFromFile("assets/flying_enemy.png");
    textureLoadOk[4] = texEnemySplitter.loadFromFile("assets/splitter_enemy.png");
    textureLoadOk[5] = texTowerCannon.loadFromFile("assets/cannon_tower.png");
    textureLoadOk[6] = texTowerSniper.loadFromFile("assets/sniper_tower.png");
    textureLoadOk[7] = texTowerMG.loadFromFile("assets/mg_tower.png");
    textureLoadOk[8] = texTowerSlow.loadFromFile("assets/slow_tower.png");
    textureLoadOk[9] = texTowerLaser.loadFromFile("assets/laser_tower.png");

    if (sbCannon.loadFromFile("assets/sounds/cannon.wav"))
    {
        sndCannon = new sf::Sound(sbCannon);
    }

    if (sbSniper.loadFromFile("assets/sounds/sniper.wav"))
    {
        sndSniper = new sf::Sound(sbSniper);
    }

    if (sbMG.loadFromFile("assets/sounds/mg.wav"))
    {
        sndMG = new sf::Sound(sbMG);
    }

    if (sbSlow.loadFromFile("assets/sounds/slow.wav"))
    {
        sndSlow = new sf::Sound(sbSlow);
    }

    if (sbLaser.loadFromFile("assets/sounds/laser.wav"))
    {
        sndLaser = new sf::Sound(sbLaser);
    }
}

void Game::playSoundForTower(int idx)
{
    sf::Sound* towerShotSound = nullptr;

    switch (idx)
    {
    case 0:
        towerShotSound = sndCannon;
        break;

    case 1:
        towerShotSound = sndSniper;
        break;

    case 2:
        towerShotSound = sndMG;
        break;

    case 3:
        towerShotSound = sndSlow;
        break;

    case 4:
        towerShotSound = sndLaser;
        break;

    default:
        break;
    }

    if (towerShotSound != nullptr
        && towerShotSound->getStatus() != sf::Sound::Status::Playing)
    {
        towerShotSound->play();
    }
}

Game::Game()
    : window(sf::VideoMode({ 1280u, 720u }), "Tower Defense Game with OOP")
    , enemyCount(0), towerCount(0)
    , gold(200), lives(20), score(0), totalKills(0)
    , state(GameState::MENU)
    , towerBuildPickIndex(-1), inspectedTower(nullptr)
    , hudToastSecondsLeft(0.f), pathGlowPhase(0.f)
    , sndCannon(nullptr), sndSniper(nullptr)
    , sndMG(nullptr), sndSlow(nullptr), sndLaser(nullptr)
{
    window.setFramerateLimit(60);

    for (int i = 0; i < 10; i++) textureLoadOk[i] = false;

    if (!font.openFromFile("C:/Windows/Fonts/arial.ttf"))
    {
        if (!font.openFromFile("C:/Windows/Fonts/calibri.ttf"))
        {
            if (!font.openFromFile("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"))
            {
                font.openFromFile("/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf");
            }
        }
    }

    for (int i = 0; i < MAX_GRID_ENEMIES; i++)
    {
        enemies[i] = nullptr;
    }

    for (int i = 0; i < MAX_TOWERS; i++)
    {
        towers[i] = nullptr;
    }

    for (int r = 0; r < ROWS; r++)
    {
        for (int c = 0; c < COLS; c++)
        {
            grid[r][c] = 0;
        }
    }

    buildPath();
    buildUI();
    loadAssets();
}

Game::~Game()
{
    clearEnemies();
    clearTowers();
    delete sndCannon;
    delete sndSniper;
    delete sndMG;
    delete sndSlow;
    delete sndLaser;
}

void Game::clearEnemies()
{
    for (int i = 0; i < MAX_GRID_ENEMIES; i++)
    {
        delete enemies[i];
        enemies[i] = nullptr;
    }
    enemyCount = 0;
}

void Game::clearTowers()
{
    for (int i = 0; i < MAX_TOWERS; i++)
    {
        delete towers[i];
        towers[i] = nullptr;
    }
    towerCount = 0;
}

void Game::buildPath()
{
    g_waypointCount = 10;
    g_waypoints[0] = { 20.f, 200.f };
    g_waypoints[1] = { 200.f, 200.f };
    g_waypoints[2] = { 200.f, 360.f };
    g_waypoints[3] = { 400.f, 360.f };
    g_waypoints[4] = { 400.f, 120.f };
    g_waypoints[5] = { 600.f, 120.f };
    g_waypoints[6] = { 600.f, 480.f };
    g_waypoints[7] = { 800.f, 480.f };
    g_waypoints[8] = { 800.f, 280.f };
    g_waypoints[9] = { 960.f, 280.f };

    for (int i = 0; i < g_waypointCount - 1; i++)
    {
        sf::Vector2f
            a = g_waypoints[i];
        sf::Vector2f
            b = g_waypoints[i + 1];
        int ac = (int)(a.x / TILE), ar = (int)(a.y / TILE);
        int bc = (int)(b.x / TILE), br = (int)(b.y / TILE);
        if (ac > bc)
        {
            int tmp = ac;
            ac = bc;
            bc = tmp;
        }
        if (ar > br)
        {
            int tmp = ar;
            ar = br;
            br = tmp;
        }
        for (int r = ar; r <= br && r < ROWS; r++)
            for (int c = ac; c <= bc && c < 25; c++)
                grid[r][c] = 1;
    }
}

void Game::buildUI()
{
    sidebar.setSize({ 280.f, 720.f });
    sidebar.setPosition({ 1000.f, 0.f });
    sidebar.setFillColor(sf::Color(30, 35, 45));
    sidebar.setOutlineColor(sf::Color(60, 70, 90));
    sidebar.setOutlineThickness(2.f);

    std::string labels[] = { "       Cannon","       Sniper","       MachineGun","       Slow","       Laser" };
    int costs[] = { 125, 175, 150, 100, 200 };

    for (int i = 0; i < 5; i++)
    {
        towerButtons[i].rect.setSize({ 240.f, 52.f });
        towerButtons[i].rect.setPosition({ 1020.f, 100.f + i * 62.f });
        towerButtons[i].rect.setFillColor(sf::Color(50, 60, 80));
        towerButtons[i].rect.setOutlineColor(sf::Color(80, 100, 130));
        towerButtons[i].rect.setOutlineThickness(2.f);
        towerButtons[i].label = labels[i];
        towerButtons[i].cost = costs[i];
        towerButtons[i].costStr = "$" + intToString(costs[i]);
    }

    startWaveBtn.setSize({ 240.f, 44.f });
    startWaveBtn.setPosition({ 1020.f, 440.f });
    startWaveBtn.setFillColor(sf::Color(40, 140, 60));
    startWaveBtn.setOutlineColor(sf::Color(60, 200, 80));
    startWaveBtn.setOutlineThickness(2.f);

    upgradeBtn.setSize({ 115.f, 36.f });
    upgradeBtn.setPosition({ 1020.f, 510.f });
    upgradeBtn.setFillColor(sf::Color(40, 100, 160));
    upgradeBtn.setOutlineColor(sf::Color(60, 140, 220));
    upgradeBtn.setOutlineThickness(2.f);

    sellBtn.setSize({ 115.f, 36.f });
    sellBtn.setPosition({ 1145.f, 510.f });
    sellBtn.setFillColor(sf::Color(140, 60, 40));
    sellBtn.setOutlineColor(sf::Color(220, 90, 60));
    sellBtn.setOutlineThickness(2.f);

    buyLivesBtn.setSize({ 240.f, 36.f });
    buyLivesBtn.setPosition({ 1020.f, 555.f });
    buyLivesBtn.setFillColor(sf::Color(60, 130, 60));
    buyLivesBtn.setOutlineColor(sf::Color(80, 200, 80));
    buyLivesBtn.setOutlineThickness(2.f);
}

void Game::run()
{
    sf::Clock clock;
    while (window.isOpen())
    {
        float dt = clock.restart().asSeconds();

        if (dt > 0.05f)
        {
            dt = 0.05f;
        }

        handleEvents();

        if (state == GameState::PLAYING)
        {
            update(dt);
        }

        render();
    }
}

void Game::handleEvents()
{
    while (auto event = window.pollEvent())
    {
        if (event->is<sf::Event::Closed>())
        {
            window.close();
            return;
        }

        if (auto* kp = event->getIf<sf::Event::KeyPressed>())
        {
            if (state == GameState::MENU && kp->code == sf::Keyboard::Key::Enter)
            {
                state = GameState::PLAYING; logGameStart();
            }
            if ((state == GameState::GAME_OVER || state == GameState::WIN)
                && kp->code == sf::Keyboard::Key::R) {
                resetGame(); return;
            }
            if (state == GameState::PLAYING) {
                if (kp->code == sf::Keyboard::Key::Escape) { towerBuildPickIndex = -1; inspectedTower = nullptr; }
                if (kp->code == sf::Keyboard::Key::Num1) towerBuildPickIndex = 0;
                if (kp->code == sf::Keyboard::Key::Num2) towerBuildPickIndex = 1;
                if (kp->code == sf::Keyboard::Key::Num3) towerBuildPickIndex = 2;
                if (kp->code == sf::Keyboard::Key::Num4) towerBuildPickIndex = 3;
                if (kp->code == sf::Keyboard::Key::Num5) towerBuildPickIndex = 4;
            }
        }
        if (auto* mb = event->getIf<sf::Event::MouseButtonPressed>()) {
            if (mb->button == sf::Mouse::Button::Left)
                handleMouseClick((float)mb->position.x, (float)mb->position.y);
        }
    }
}

void Game::handleMouseClick(float mx, float my)
{
    if (state == GameState::MENU)
    {
        state = GameState::PLAYING;
        logGameStart();
        return;
    }
    if (state != GameState::PLAYING)
        return;

    if (startWaveBtn.getGlobalBounds().contains({ mx, my }))
    {
        if (!waveManager.isWaveActive() && !waveManager.isAllDone())
        {
            waveManager.startWave();
            showFlash(waveManager.getDescription());
            logWave(waveManager.getCurrentWave());
        }
        return;
    }

    if (buyLivesBtn.getGlobalBounds().contains({ mx, my }))
    {
        const int COST = 75, AMT = 5;
        if (gold >= COST)
        {
            gold -= COST; lives += AMT;
            showFlash("+" + intToString(AMT) + " lives purchased!");
            std::cout << "[BUY LIVES]  +" << AMT << " lives  |  Lives: "
                << lives << "  |  Gold: " << gold << "\n";
        }
        else {
            showFlash("Not enough gold! ($75 needed)");
        }
        return;
    }

    for (int i = 0; i < 5; i++) {
        if (towerButtons[i].rect.getGlobalBounds().contains({ mx, my })) {
            towerBuildPickIndex = i; inspectedTower = nullptr; return;
        }
    }

    if (inspectedTower && upgradeBtn.getGlobalBounds().contains({ mx, my })) {
        if (!inspectedTower->canUpgrade()) { showFlash("Max level!"); return; }
        int uc = inspectedTower->getUpgradeCost();
        if (gold >= uc) {
            gold -= uc; inspectedTower->upgrade(); showFlash("Upgraded!");
            std::cout << "[UPGRADE]  " << inspectedTower->getName()
                << " -> Level " << inspectedTower->getLevel()
                << "  |  Gold: " << gold << "\n";
        }
        else showFlash("Not enough gold!");
        return;
    }

    if (inspectedTower && sellBtn.getGlobalBounds().contains({ mx, my })) {
        int refund = (int)(inspectedTower->getCost() * 0.6f);
        gold += refund;
        int sc = (int)(inspectedTower->getX() / TILE);
        int sr = (int)(inspectedTower->getY() / TILE);
        if (sr >= 0 && sr < ROWS && sc >= 0 && sc < COLS) grid[sr][sc] = 0;
        std::cout << "[SELL]  " << inspectedTower->getName()
            << "  +" << refund << " gold  |  Gold: " << gold << "\n";
        for (int i = 0; i < MAX_TOWERS; i++) {
            if (towers[i] == inspectedTower) {
                delete towers[i]; towers[i] = nullptr; towerCount--; break;
            }
        }
        inspectedTower = nullptr;
        showFlash("Sold! +" + intToString(refund) + " gold");
        return;
    }

    if (mx < 1000.f) {
        int col = (int)(mx / TILE);
        int row = (int)(my / TILE);
        if (row < 0 || row >= ROWS || col < 0 || col >= 25) return;

        if (towerBuildPickIndex == -1 || grid[row][col] == 2) {
            inspectedTower = nullptr;
            float cx = col * TILE + TILE / 2.f, cy = row * TILE + TILE / 2.f;
            for (int i = 0; i < MAX_TOWERS; i++) {
                if (!towers[i]) continue;
                if (std::abs(towers[i]->getX() - cx) < TILE / 2.f &&
                    std::abs(towers[i]->getY() - cy) < TILE / 2.f) {
                    inspectedTower = towers[i]; towerBuildPickIndex = -1; break;
                }
            }
            return;
        }
        if (towerBuildPickIndex >= 0) placeTower(col, row);
    }
}

void Game::placeTower(int col, int row)
{
    if (grid[row][col] != 0) { showFlash("Can't place here!"); return; }
    if (towerCount >= MAX_TOWERS) { showFlash("Tower limit reached!"); return; }

    int costs[] = { 125, 175, 150, 100, 200 };
    int cost = costs[towerBuildPickIndex];
    if (gold < cost) { showFlash("Not enough gold!"); return; }

    float cx = col * TILE + TILE / 2.f, cy = row * TILE + TILE / 2.f;
    Tower* t = nullptr;
    switch (towerBuildPickIndex) {
    case 0: t = new CannonTower(cx, cy);     break;
    case 1: t = new SniperTower(cx, cy);     break;
    case 2: t = new MachineGunTower(cx, cy); break;
    case 3: t = new SlowTower(cx, cy);       break;
    case 4: t = new LaserTower(cx, cy);      break;
    default: return;
    }

    t->setGame(this, towerBuildPickIndex);
    if (textureLoadOk[5 + towerBuildPickIndex])
        t->setTexture(&towerTextureByIndex(towerBuildPickIndex));

    for (int i = 0; i < MAX_TOWERS; i++) {
        if (!towers[i]) { towers[i] = t; towerCount++; break; }
    }
    gold -= cost;
    grid[row][col] = 2;
    std::cout << "[PLACE]  " << t->getName()
        << " at (" << col << "," << row << ")"
        << "  |  Gold: " << gold << "\n";
}

void Game::spawnEnemy(int type)
{
    if (enemyCount >= MAX_GRID_ENEMIES) return;
    Enemy* e = nullptr;
    switch (type) {
    case 0: e = new BasicEnemy();    break;
    case 1: e = new FastEnemy();     break;
    case 2: e = new TankEnemy();     break;
    case 3: e = new FlyingEnemy();   break;
    case 4: e = new SplitterEnemy(); break;
    default: e = new BasicEnemy();   break;
    }
    if (textureLoadOk[type]) e->setTexture(&enemyTextureByIndex(type));
    for (int i = 0; i < MAX_GRID_ENEMIES; i++) {
        if (!enemies[i]) { enemies[i] = e; enemyCount++; return; }
    }
    delete e;
}

void Game::update(float dt)
{
    pathGlowPhase += dt * 2.f;
    if (hudToastSecondsLeft > 0) hudToastSecondsLeft -= dt;

    bool enemiesEmpty = (enemyCount == 0);
    int spawnType = waveManager.update(dt, enemiesEmpty);
    if (spawnType >= 0) spawnEnemy(spawnType);

    for (int i = 0; i < MAX_GRID_ENEMIES; i++) {
        if (!enemies[i]) continue;
        enemies[i]->update(dt);

        if (enemies[i]->hasReachedEnd()) {
            int dmg = enemies[i]->getDamage();
            lives -= dmg;
            logLifeLost(dmg, lives);
            if (lives <= 0) {
                lives = 0; state = GameState::GAME_OVER; logLoss(); return;
            }
            delete enemies[i]; enemies[i] = nullptr; enemyCount--;
            continue;
        }

        SplitterEnemy* sp = dynamic_cast<SplitterEnemy*>(enemies[i]);
        if (sp && sp->hasSplit && !enemies[i]->isActive()) {
            gold += enemies[i]->getReward();
            score += enemies[i]->getReward();
            logKill(enemies[i]->getName(), enemies[i]->getReward());
            delete enemies[i]; enemies[i] = nullptr; enemyCount--;
            spawnEnemy(0); spawnEnemy(0);
            continue;
        }

        if (!enemies[i]->isActive()) {
            gold += enemies[i]->getReward();
            score += enemies[i]->getReward();
            logKill(enemies[i]->getName(), enemies[i]->getReward());
            delete enemies[i]; enemies[i] = nullptr; enemyCount--;
        }
    }

    for (int i = 0; i < MAX_TOWERS; i++)
        if (towers[i]) towers[i]->attack(enemies, MAX_GRID_ENEMIES, dt);

    if (waveManager.isAllDone() && enemyCount == 0) {
        state = GameState::WIN; logWin();
    }
}

void Game::drawText(const std::string& txt, float tx, float ty,
    unsigned sz, sf::Color col)
{
    sf::Text t(font, txt, sz);
    t.setFillColor(col);
    t.setPosition({ tx, ty });
    window.draw(t);
}

void Game::drawCentered(const std::string& txt, float ty, unsigned sz, sf::Color col)
{
    sf::Text t(font, txt, sz);
    t.setFillColor(col);
    sf::FloatRect b = t.getLocalBounds();
    t.setPosition({ (1280.f - b.size.x) / 2.f, ty });
    window.draw(t);
}

void Game::render()
{
    window.clear(sf::Color(20, 25, 30));
    switch (state) {
    case GameState::MENU:      renderMenu();    break;
    case GameState::PLAYING:   renderMap(); renderHUD(); break;
    case GameState::GAME_OVER: renderMap(); renderHUD(); renderGameOver(); break;
    case GameState::WIN:       renderMap(); renderHUD(); renderWin(); break;
    }
    window.display();
}

void Game::renderMap()
{
    for (int r = 0; r < ROWS; r++) {
        for (int c = 0; c < 25; c++) {
            sf::RectangleShape tile({ 39.f, 39.f });
            tile.setPosition({ c * 40.f + 0.5f, r * 40.f + 0.5f });
            if (grid[r][c] == 1) {
                float pulse = (std::sin(pathGlowPhase) + 1.f) * 0.5f;
                tile.setFillColor(sf::Color(
                    (uint8_t)(160 + pulse * 20),
                    (uint8_t)(130 + pulse * 15),
                    (uint8_t)(80 + pulse * 10)));
            }
            else {
                tile.setFillColor(sf::Color(34, 60, 34));
            }
            tile.setOutlineColor(sf::Color(0, 0, 0, 40));
            tile.setOutlineThickness(0.5f);
            window.draw(tile);
        }
    }

    for (int i = 0; i < g_waypointCount - 1; i++) {
        sf::Vector2f a = g_waypoints[i], b = g_waypoints[i + 1];
        float dx = b.x - a.x, dy = b.y - a.y;
        float dist = std::sqrt(dx * dx + dy * dy);
        int steps = (int)(dist / 60.f);
        for (int s = 1; s < steps; s++) {
            float t = (float)s / steps;
            sf::CircleShape dot(3.f, 3);
            dot.setFillColor(sf::Color(255, 220, 100, 120));
            dot.setOrigin({ 3.f, 3.f });
            dot.setPosition({ a.x + dx * t, a.y + dy * t });
            window.draw(dot);
        }
    }

    sf::CircleShape entry(12.f);
    entry.setFillColor(sf::Color(0, 220, 0, 180));
    entry.setOrigin({ 12.f, 12.f });
    entry.setPosition(g_waypoints[0]);
    window.draw(entry);

    sf::CircleShape exitM(12.f);
    exitM.setFillColor(sf::Color(220, 0, 0, 180));
    exitM.setOrigin({ 12.f, 12.f });
    exitM.setPosition(g_waypoints[g_waypointCount - 1]);
    window.draw(exitM);

    drawText("IN", g_waypoints[0].x - 10.f, g_waypoints[0].y - 28.f, 11, sf::Color::Green);
    drawText("OUT", g_waypoints[g_waypointCount - 1].x - 12.f,
        g_waypoints[g_waypointCount - 1].y - 28.f, 11, sf::Color::Red);

    if (towerBuildPickIndex >= 0) {
        sf::Vector2i mp = sf::Mouse::getPosition(window);
        if (mp.x < 1000) {
            int hc = mp.x / TILE, hr = mp.y / TILE;
            if (hr >= 0 && hr < ROWS && hc >= 0 && hc < 25) {
                bool ok = (grid[hr][hc] == 0);
                sf::RectangleShape hov({ 38.f, 38.f });
                hov.setPosition({ hc * 40.f + 1.f, hr * 40.f + 1.f });
                hov.setFillColor(ok ? sf::Color(0, 255, 0, 60) : sf::Color(255, 0, 0, 60));
                hov.setOutlineColor(ok ? sf::Color(0, 255, 0, 150) : sf::Color(255, 0, 0, 150));
                hov.setOutlineThickness(2.f);
                window.draw(hov);
            }
        }
    }

    if (inspectedTower) {
        float rng = inspectedTower->getRange();
        sf::CircleShape sel(rng);
        sel.setFillColor(sf::Color(255, 255, 100, 25));
        sel.setOutlineColor(sf::Color(255, 255, 100, 120));
        sel.setOutlineThickness(2.f);
        sel.setOrigin({ rng, rng });
        sel.setPosition({ inspectedTower->getX(), inspectedTower->getY() });
        window.draw(sel);
    }

    for (int i = 0; i < MAX_TOWERS; i++) if (towers[i])  towers[i]->render(window);
    for (int i = 0; i < MAX_GRID_ENEMIES; i++) if (enemies[i]) enemies[i]->render(window);
}

void Game::renderHUD()
{
    window.draw(sidebar);
    drawText("TOWER DEFENSE", 1020.f, 10.f, 18, sf::Color(100, 200, 255));
    drawText("GOLD: " + intToString(gold), 1020.f, 38.f, 14, sf::Color(255, 215, 0));
    drawText("LIVES: " + intToString(lives), 1130.f, 38.f, 14,
        lives > 10 ? sf::Color(0, 220, 0) : lives > 5 ? sf::Color(255, 180, 0) : sf::Color(220, 0, 0));
    drawText("Wave:" + intToString(waveManager.getCurrentWave()) + "/" +
        intToString(waveManager.getTotalWaves()) +
        "  Score:" + intToString(score) + "  K:" + intToString(totalKills),
        1020.f, 58.f, 11, sf::Color(180, 200, 220));

    sf::Color swatchColors[] = {
        sf::Color(100,100,120), sf::Color(60,90,60),
        sf::Color(140,100,60),  sf::Color(50,120,180), sf::Color(180,50,50)
    };
    std::string descs[] = {
        "","",
        "", "",""
    };

    for (int i = 0; i < 5; i++) {
        towerButtons[i].rect.setFillColor(
            towerBuildPickIndex == i ? sf::Color(80, 100, 140) : sf::Color(45, 55, 72));
        towerButtons[i].rect.setOutlineColor(
            towerBuildPickIndex == i ? sf::Color(100, 180, 255) : sf::Color(70, 85, 110));
        window.draw(towerButtons[i].rect);

        if (textureLoadOk[5 + i]) {
            sf::Sprite sw(towerTextureByIndex(i));
            float s = 38.f / (float)towerTextureByIndex(i).getSize().x;
            sw.setScale({ s, s });
            sw.setPosition({ 1020.f, 100.f + i * 62.f + 7.f });
            window.draw(sw);
        }
        else {
            sf::RectangleShape sw({ 10.f, 38.f });
            sw.setFillColor(swatchColors[i]);
            sw.setPosition({ 1020.f, 100.f + i * 62.f + 7.f });
            window.draw(sw);
        }
        drawText(towerButtons[i].label, 1036.f, 103.f + i * 62.f, 13, sf::Color(220, 230, 240));
        drawText(descs[i], 1036.f, 119.f + i * 62.f, 10, sf::Color(160, 170, 185));
        drawText(towerButtons[i].costStr, 1200.f, 119.f + i * 62.f, 11, sf::Color(255, 215, 0));
    }

    sf::RectangleShape sep({ 240.f, 1.f });
    sep.setFillColor(sf::Color(60, 70, 90));
    sep.setPosition({ 1020.f, 435.f });
    window.draw(sep);

    bool running = waveManager.isWaveActive(), done = waveManager.isAllDone();
    std::string wl = done ? "ALL WAVES DONE!"
        : running ? "Wave in progress..."
        : "START WAVE " + intToString(waveManager.getCurrentWave());
    startWaveBtn.setFillColor(done ? sf::Color(60, 60, 60)
        : running ? sf::Color(80, 60, 40)
        : sf::Color(40, 140, 60));
    window.draw(startWaveBtn);
    drawText(wl, 1030.f, 451.f, 12, done ? sf::Color(130, 130, 130) : sf::Color::White);

    if (inspectedTower) {
        drawText("--- Tower Info ---", 1020.f, 495.f, 12, sf::Color(180, 200, 220));
        int dmgInt = (int)inspectedTower->getDamage();
        int dmgFrac = (int)((inspectedTower->getDamage() - dmgInt) * 10);
        std::string stats = "Dmg:" + intToString(dmgInt) + "." + intToString(dmgFrac)
            + " Rng:" + intToString((int)inspectedTower->getRange())
            + " Lv:" + intToString(inspectedTower->getLevel());
        drawText(stats, 1020.f, 510.f, 10, sf::Color(160, 175, 190));

        if (inspectedTower->canUpgrade()) {
            window.draw(upgradeBtn);
            drawText("Upgrade $" + intToString(inspectedTower->getUpgradeCost()),
                1026.f, 519.f, 10,
                gold >= inspectedTower->getUpgradeCost()
                ? sf::Color::White : sf::Color(180, 100, 100));
        }
        else {
            sf::RectangleShape mb({ 115.f, 36.f });
            mb.setFillColor(sf::Color(50, 50, 50));
            mb.setPosition({ 1020.f, 510.f });
            window.draw(mb);
            drawText("MAX LEVEL", 1032.f, 519.f, 10, sf::Color(130, 130, 130));
        }
        window.draw(sellBtn);
        drawText("Sell +$" + intToString((int)(inspectedTower->getCost() * 0.6f)),
            1151.f, 519.f, 10, sf::Color::White);
    }

    buyLivesBtn.setFillColor(gold >= 75 ? sf::Color(50, 130, 50) : sf::Color(50, 50, 50));
    buyLivesBtn.setOutlineColor(gold >= 75 ? sf::Color(80, 200, 80) : sf::Color(80, 80, 80));
    window.draw(buyLivesBtn);
    drawText("+5 Lives  ($75)", 1030.f, 563.f, 12,
        gold >= 75 ? sf::Color(180, 255, 180) : sf::Color(100, 100, 100));

    float ly = 605.f;
    drawText("", 1020.f, ly, 11, sf::Color(140, 160, 180)); ly += 15.f;
    sf::Color lc[] = {
        sf::Color(200,80,80), sf::Color(80,220,80), sf::Color(120,120,180),
        sf::Color(220,180,50), sf::Color(220,100,220)
    };
    std::string ln[] = { " Basic"," Fast"," Tank"," Flying"," Splitter" };
    for (int i = 0; i < 5; i++) {
        if (textureLoadOk[i]) {
            sf::Sprite sp(enemyTextureByIndex(i));
            float s = 14.f / (float)enemyTextureByIndex(i).getSize().x;
            sp.setScale({ s, s });
            sp.setPosition({ 1020.f, ly });
            window.draw(sp);
        }
        else {
            sf::CircleShape dot(6.f);
            dot.setFillColor(lc[i]);
            dot.setPosition({ 1020.f, ly });
            window.draw(dot);
        }
        drawText(ln[i], 1036.f, ly - 2.f, 10, sf::Color(180, 190, 200));
        ly += 16.f;
    }

    drawText("[ESC]Deselect  [1-5]Select", 1020.f, 695.f, 9, sf::Color(100, 110, 125));

    if (hudToastSecondsLeft > 0) {
        float alpha = hudToastSecondsLeft < 0.5f ? hudToastSecondsLeft / 0.5f : 1.f;
        sf::Text fl(font, hudToastMessage, 16);
        fl.setFillColor(sf::Color(255, 240, 100, (uint8_t)(alpha * 255)));
        fl.setPosition({ 10.f, 690.f });
        window.draw(fl);
    }
}

void Game::renderMenu()
{
    window.clear(sf::Color(10, 15, 25));
    drawCentered("TOWER DEFENSE", 150.f, 60, sf::Color(100, 200, 255));
    drawCentered("8 Waves | 5 Towers | 5 Enemies", 290.f, 16, sf::Color(180, 200, 150));

    sf::Color ec[] = {
        sf::Color(200,80,80), sf::Color(80,220,80), sf::Color(120,120,180),
        sf::Color(220,180,50), sf::Color(220,100,220)
    };
    std::string el[] = { "Basic","Fast","Tank","Flyer","Splitter" };
    for (int i = 0; i < 5; i++) {
        if (textureLoadOk[i]) {
            sf::Sprite sp(enemyTextureByIndex(i));
            float s = 32.f / (float)enemyTextureByIndex(i).getSize().x;
            sp.setScale({ s, s });
            sp.setPosition({ 234.f + i * 155.f, 354.f });
            window.draw(sp);
        }
        else {
            sf::CircleShape c(16.f);
            c.setFillColor(ec[i]);
            c.setOutlineColor(sf::Color::Black);
            c.setOutlineThickness(2.f);
            c.setOrigin({ 16.f, 16.f });
            c.setPosition({ 250.f + i * 155.f, 370.f });
            window.draw(c);
        }
        drawText(el[i], 230.f + i * 155.f, 393.f, 12, sf::Color(220, 220, 220));
    }

    drawCentered("HOW TO PLAY:", 440.f, 18, sf::Color(255, 215, 0));
    drawCentered("Press [1-5] to select tower, left-click grass to place", 468.f, 14, sf::Color(200, 210, 220));
    drawCentered("Click START WAVE to begin. Click tower to upgrade/sell", 488.f, 14, sf::Color(200, 210, 220));
    drawCentered("Buy +5 Lives for $75 via the sidebar button.", 508.f, 14, sf::Color(180, 255, 180));
    drawCentered("Survive all 8 waves to win!", 530.f, 14, sf::Color(200, 210, 220));
    drawCentered("CLICK or press ENTER to start", 590.f, 24, sf::Color(100, 255, 100));
}

void Game::renderGameOver()
{
    sf::RectangleShape ov({ 1280.f, 720.f });
    ov.setFillColor(sf::Color(0, 0, 0, 160));
    window.draw(ov);
    drawCentered("GAME OVER", 220.f, 72, sf::Color(220, 30, 30));
    drawCentered("Enemies reached the base!", 310.f, 20, sf::Color(220, 180, 100));
    drawCentered("Score: " + intToString(score), 355.f, 24, sf::Color(255, 215, 0));
    drawCentered("Kills: " + intToString(totalKills), 385.f, 20, sf::Color(200, 220, 255));
    drawCentered("Wave: " + intToString(waveManager.getCurrentWave()) + "/" +
        intToString(waveManager.getTotalWaves()), 415.f, 18, sf::Color(180, 200, 220));
    drawCentered("Press [R] to restart", 470.f, 22, sf::Color(100, 220, 100));
}

void Game::renderWin()
{
    sf::RectangleShape ov({ 1280.f, 720.f });
    ov.setFillColor(sf::Color(0, 0, 0, 140));
    window.draw(ov);
    drawCentered("VICTORY!", 200.f, 80, sf::Color(255, 215, 0));
    drawCentered("All waves defeated!", 305.f, 20, sf::Color(100, 220, 150));
    drawCentered("Final Score: " + intToString(score), 350.f, 28, sf::Color(255, 215, 0));
    drawCentered("Total Kills: " + intToString(totalKills), 385.f, 22, sf::Color(200, 220, 255));
    drawCentered("Lives left: " + intToString(lives), 420.f, 20, sf::Color(100, 220, 100));
    drawCentered("Gold left: " + intToString(gold), 450.f, 20, sf::Color(255, 215, 0));
    drawCentered("Press [R] to play again", 510.f, 22, sf::Color(100, 200, 255));
}

void Game::resetGame()
{
    clearEnemies();
    clearTowers();

    gold = 200;
    lives = 20;
    score = 0;
    totalKills = 0;

    state = GameState::PLAYING;
    towerBuildPickIndex = -1;
    inspectedTower = nullptr;
    hudToastMessage = "";
    hudToastSecondsLeft = 0.f;
    pathGlowPhase = 0.f;

    for (int r = 0; r < ROWS; r++)
    {
        for (int c = 0; c < COLS; c++)
        {
            grid[r][c] = 0;
        }
    }
    buildPath();
    waveManager = WaveManager();
    logGameStart();
}

bool Game::isOnPath(int col, int row) const
{
    if (row < 0 || row >= ROWS || col < 0 || col >= COLS)
    {
        return false;
    }

    return grid[row][col] == 1;
}

bool Game::hasTower(int col, int row) const
{
    if (row < 0 || row >= ROWS || col < 0 || col >= COLS)
    {
        return false;
    }

    return grid[row][col] == 2;
}
