#include "Game.h"

int main()
{
    Game towerDefenseGame;

    towerDefenseGame.run();

    return 0;
}
