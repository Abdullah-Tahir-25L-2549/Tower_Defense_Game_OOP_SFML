#pragma once
#include <SFML/Graphics.hpp>
#include <string>
#include <cmath>
#include "Entity.h"

static const int MAX_WAYPOINTS = 20;
static sf::Vector2f g_waypoints[MAX_WAYPOINTS];
static int          g_waypointCount = 0;

class Enemy : public Entity
{
protected:
    float hitPoints;
    float maxHitPoints;
    float moveSpeed;
    int   bountyGold;
    int   waypointIndex;
    float travelAlphaAlongSegment;
    bool  reachedExit;
    int   damageIfEscapes;
    sf::Color fallbackBodyColor;
    float slowEffectSecondsLeft;

    const sf::Texture* texture;

    void drawHealthBar(sf::RenderWindow& window, float barWidth, float barHeight) const
    {
        sf::RectangleShape background({ barWidth, barHeight });
        background.setFillColor(sf::Color(80, 0, 0));
        background.setPosition({ x - barWidth / 2.f, y - 24.f });
        window.draw(background);

        float healthRatio = hitPoints / maxHitPoints;
        sf::RectangleShape foreground({ barWidth * healthRatio, barHeight });
        sf::Color fillColor = sf::Color(0, 200, 0);

        if (healthRatio <= 0.25f)
        {
            fillColor = sf::Color(220, 0, 0);
        }
        else if (healthRatio <= 0.5f)
        {
            fillColor = sf::Color(220, 180, 0);
        }

        foreground.setFillColor(fillColor);
        foreground.setPosition({ x - barWidth / 2.f, y - 24.f });
        window.draw(foreground);
    }

public:
    Enemy(float maxHp, float speed, int goldReward, int baseDamage,
        const std::string& displayName, sf::Color fallbackColor)
        : Entity(0, 0, displayName)
        , hitPoints(maxHp)
        , maxHitPoints(maxHp)
        , moveSpeed(speed)
        , bountyGold(goldReward)
        , waypointIndex(0)
        , travelAlphaAlongSegment(0.f)
        , reachedExit(false)
        , damageIfEscapes(baseDamage)
        , fallbackBodyColor(fallbackColor)
        , slowEffectSecondsLeft(0.f)
        , texture(nullptr)
    {
        if (g_waypointCount > 0)
        {
            x = g_waypoints[0].x;
            y = g_waypoints[0].y;
        }
    }

    virtual ~Enemy()
    {}

    void setTexture(const sf::Texture* loadedTexture)
    {
        texture = loadedTexture;
    }

    virtual void move(float deltaSeconds)
    {
        if (waypointIndex >= g_waypointCount - 1)
        {
            reachedExit = true;
            active = false;

            return;
        }

        float effectiveSpeed = moveSpeed;

        if (slowEffectSecondsLeft > 0.f)
        {
            effectiveSpeed = moveSpeed * 0.4f;
            slowEffectSecondsLeft -= deltaSeconds;
        }

        sf::Vector2f segmentStart = g_waypoints[waypointIndex];
        sf::Vector2f segmentEnd = g_waypoints[waypointIndex + 1];
        sf::Vector2f segmentDelta = segmentEnd - segmentStart;
        float segmentLength = std::sqrt(segmentDelta.x * segmentDelta.x + segmentDelta.y * segmentDelta.y);

        if (segmentLength == 0.f)
        {
            waypointIndex++;

            return;
        }

        travelAlphaAlongSegment += (effectiveSpeed * deltaSeconds) / segmentLength;

        if (travelAlphaAlongSegment >= 1.f)
        {
            travelAlphaAlongSegment -= 1.f;
            waypointIndex++;

            if (waypointIndex >= g_waypointCount - 1)
            {
                reachedExit = true;
                active = false;

                return;
            }

            segmentStart = g_waypoints[waypointIndex];
            segmentEnd = g_waypoints[waypointIndex + 1];
        }

        x = segmentStart.x + (segmentEnd.x - segmentStart.x) * travelAlphaAlongSegment;
        y = segmentStart.y + (segmentEnd.y - segmentStart.y) * travelAlphaAlongSegment;
    }

    virtual void takeDamage(float amount)
    {
        hitPoints -= amount;

        if (hitPoints <= 0.f)
        {
            active = false;
        }
    }

    void applySlowEffect(float durationSeconds)
    {
        if (durationSeconds > slowEffectSecondsLeft)
        {
            slowEffectSecondsLeft = durationSeconds;
        }
    }

    void update(float deltaSeconds) override
    {
        move(deltaSeconds);
    }

    void drawBody(sf::RenderWindow& window, float drawRadius) const
    {
        if (texture != nullptr)
        {
            sf::Sprite sprite(*texture);
            float scale = (drawRadius * 2.f) / (float)texture->getSize().x;
            sprite.setScale({ scale, scale });
            sprite.setOrigin({ (float)texture->getSize().x / 2.f,
                               (float)texture->getSize().y / 2.f });
            sprite.setPosition({ x, y });
            window.draw(sprite);
        }
        else
        {
            sf::CircleShape body(drawRadius);
            body.setFillColor(fallbackBodyColor);
            body.setOutlineColor(sf::Color::Black);
            body.setOutlineThickness(2.f);
            body.setOrigin({ drawRadius, drawRadius });
            body.setPosition({ x, y });
            window.draw(body);
        }
    }

    void render(sf::RenderWindow& window) override
    {
        drawBody(window, 14.f);
        drawHealthBar(window, 30.f, 5.f);
    }

    float getHp() const
    {
        return hitPoints;
    }

    float getMaxHp() const
    {
        return maxHitPoints;
    }

    int getReward() const
    {
        return bountyGold;
    }

    bool hasReachedEnd() const
    {
        return reachedExit;
    }

    int getDamage() const
    {
        return damageIfEscapes;
    }

    float getProgress() const
    {
        return (float)waypointIndex + travelAlphaAlongSegment;
    }
};


class BasicEnemy : public Enemy
{
public:
    BasicEnemy()
        : Enemy(80.f, 70.f, 10, 1, "BasicEnemy", sf::Color(200, 80, 80))
    {}

    void update(float deltaSeconds) override
    {
        move(deltaSeconds);
    }

    void render(sf::RenderWindow& w) override
    {
        drawBody(w, 30.f);
        drawHealthBar(w, 30.f, 5.f);
    }
};


class FastEnemy : public Enemy
{
public:
    FastEnemy()
        : Enemy(30.f, 160.f, 15, 1, "FastEnemy", sf::Color(80, 220, 80))
    {}

    void update(float deltaSeconds) override
    {
        move(deltaSeconds);
    }

    void render(sf::RenderWindow& window) override
    {
        if (texture != nullptr)
        {
            drawBody(window, 30.f);
        }
        else
        {
            sf::ConvexShape diamond;
            diamond.setPointCount(4);
            diamond.setPoint(0, { 0.f, -16.f });
            diamond.setPoint(1, { 12.f, 0.f });
            diamond.setPoint(2, { 0.f, 16.f });
            diamond.setPoint(3, { -12.f, 0.f });
            diamond.setFillColor(fallbackBodyColor);
            diamond.setOutlineColor(sf::Color::Black);
            diamond.setOutlineThickness(2.f);
            diamond.setPosition({ x, y });
            window.draw(diamond);
        }

        drawHealthBar(window, 28.f, 4.f);
    }
};


class TankEnemy : public Enemy
{
public:
    TankEnemy()
        : Enemy(500.f, 35.f, 40, 2, "TankEnemy", sf::Color(120, 120, 180))
    {}

    void update(float deltaSeconds) override
    {
        move(deltaSeconds);
    }

    void render(sf::RenderWindow& window) override
    {
        if (texture != nullptr)
        {
            drawBody(window, 32.f);
        }
        else
        {
            sf::RectangleShape hull({ 32.f, 32.f });
            hull.setFillColor(fallbackBodyColor);
            hull.setOutlineColor(sf::Color::Black);
            hull.setOutlineThickness(3.f);
            hull.setOrigin({ 16.f, 16.f });
            hull.setPosition({ x, y });
            window.draw(hull);
        }

        drawHealthBar(window, 34.f, 6.f);
    }
};


class FlyingEnemy : public Enemy
{
private:
    sf::Vector2f flightStart;
    sf::Vector2f flightEnd;
    float distanceTraveled;
    float flightLength;

public:
    FlyingEnemy()
        : Enemy(60.f, 90.f, 25, 1, "FlyingEnemy", sf::Color(220, 180, 50))
        , distanceTraveled(0.f)
        , flightLength(1.f)
    {
        if (g_waypointCount >= 2)
        {
            flightStart = g_waypoints[0];
            flightEnd = g_waypoints[g_waypointCount - 1];
            x = flightStart.x;
            y = flightStart.y;
            sf::Vector2f span = flightEnd - flightStart;
            flightLength = std::sqrt(span.x * span.x + span.y * span.y);
        }
    }

    void move(float deltaSeconds) override
    {
        float effectiveSpeed = moveSpeed;

        if (slowEffectSecondsLeft > 0.f)
        {
            effectiveSpeed = moveSpeed * 0.4f;
            slowEffectSecondsLeft -= deltaSeconds;
        }

        distanceTraveled += effectiveSpeed * deltaSeconds;

        if (distanceTraveled >= flightLength)
        {
            reachedExit = true;
            active = false;

            return;
        }

        float flightT = distanceTraveled / flightLength;
        x = flightStart.x + (flightEnd.x - flightStart.x) * flightT;
        y = flightStart.y + (flightEnd.y - flightStart.y) * flightT;
        waypointIndex = (int)(flightT * 10.f);
        travelAlphaAlongSegment = flightT;
    }

    void update(float deltaSeconds) override
    {
        move(deltaSeconds);
    }

    void render(sf::RenderWindow& window) override
    {
        if (texture != nullptr)
        {
            drawBody(window, 30.f);
        }
        else
        {
            sf::ConvexShape wing;
            wing.setPointCount(6);
            wing.setPoint(0, { -18.f, 0.f });
            wing.setPoint(1, { -6.f, -10.f });
            wing.setPoint(2, { 0.f, -4.f });
            wing.setPoint(3, { 18.f, 0.f });
            wing.setPoint(4, { 0.f, 4.f });
            wing.setPoint(5, { -6.f, 10.f });
            wing.setFillColor(fallbackBodyColor);
            wing.setOutlineColor(sf::Color::Black);
            wing.setOutlineThickness(2.f);
            wing.setPosition({ x, y });
            window.draw(wing);
        }

        drawHealthBar(window, 30.f, 4.f);
    }
};


class SplitterEnemy : public Enemy
{
public:
    bool hasSplit;

    SplitterEnemy()
        : Enemy(150.f, 55.f, 30, 1, "SplitterEnemy", sf::Color(220, 100, 220))
        , hasSplit(false)
    {}

    void takeDamage(float amount) override
    {
        hitPoints -= amount;

        if (hitPoints <= 0.f && !hasSplit)
        {
            hasSplit = true;
            active = false;
        }
    }

    void update(float deltaSeconds) override
    {
        move(deltaSeconds);
    }

    void render(sf::RenderWindow& window) override
    {
        if (texture != nullptr)
        {
            drawBody(window, 30.f);
        }
        else
        {
            sf::CircleShape outerRing(16.f, 8);
            outerRing.setFillColor(fallbackBodyColor);
            outerRing.setOutlineColor(sf::Color::Black);
            outerRing.setOutlineThickness(2.f);
            outerRing.setOrigin({ 16.f, 16.f });
            outerRing.setPosition({ x, y });
            window.draw(outerRing);

            sf::CircleShape core(8.f);
            core.setFillColor(sf::Color(255, 180, 255));
            core.setOrigin({ 8.f, 8.f });
            core.setPosition({ x, y });
            window.draw(core);
        }

        drawHealthBar(window, 30.f, 5.f);
    }
};
