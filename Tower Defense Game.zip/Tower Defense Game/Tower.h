#pragma once
#include <SFML/Graphics.hpp>
#include <cmath>
#include <string>
#include "Enemy.h"

static const int MAX_PROJECTILES = 30;
static const int MAX_ENEMIES = 100;

class Game;

struct Projectile
{
    float posX, posY, velX, velY, damage, speed, hitRadius, slowDurationSeconds;

    bool alive, appliesSlow;

    sf::Color tint;

    Projectile()
        : posX(0.f)
        , posY(0.f)
        , velX(0.f)
        , velY(0.f)
        , damage(0.f)
        , speed(0.f)
        , hitRadius(5.f)
        , alive(false)
        , appliesSlow(false)
        , slowDurationSeconds(0.f)
        , tint(sf::Color::White)
    {}

    void init(float startX, float startY, float targetX, float targetY,
        float damageAmount, float travelSpeed, sf::Color projectileColor,
        float radius = 5.f, bool slowShot = false, float slowSeconds = 0.f)
    {
        posX = startX;
        posY = startY;
        damage = damageAmount;
        speed = travelSpeed;
        tint = projectileColor;
        hitRadius = radius;
        appliesSlow = slowShot;
        slowDurationSeconds = slowSeconds;
        alive = true;

        float deltaX = targetX - startX;
        float deltaY = targetY - startY;
        float distance = std::sqrt(deltaX * deltaX + deltaY * deltaY);

        if (distance > 0.f)
        {
            velX = deltaX / distance * travelSpeed;
            velY = deltaY / distance * travelSpeed;
        }
        else
        {
            velX = 0.f;
            velY = 0.f;
        }
    }

    void update(float deltaSeconds)
    {
        posX += velX * deltaSeconds;
        posY += velY * deltaSeconds;
    }

    void render(sf::RenderWindow& window) const
    {
        sf::CircleShape dot(hitRadius);
        dot.setFillColor(tint);
        dot.setOrigin({ hitRadius, hitRadius });
        dot.setPosition({ posX, posY });
        window.draw(dot);
    }
};


class Tower : public Entity
{
protected:
    float attackRange;
    float shotDamage;
    float shotsPerSecond;
    float secondsUntilNextShot;
    int   goldCost;
    int   upgradeLevel;
    sf::Color bodyFillColor;
    sf::Color accentFillColor;
    Projectile projectilePool[MAX_PROJECTILES];

    Game* owningGame;
    int   soundIndex;
    const sf::Texture* texture;

    Enemy* findFarthestTargetAlongPath(Enemy** enemySlots, int slotCount)
    {
        Enemy* bestTarget = nullptr;
        float bestPathProgress = -1.f;

        for (int slot = 0; slot < slotCount; slot++)
        {
            if (enemySlots[slot] == nullptr)
            {
                continue;
            }

            if (!enemySlots[slot]->isActive())
            {
                continue;
            }

            float deltaX = enemySlots[slot]->getX() - x;
            float deltaY = enemySlots[slot]->getY() - y;
            float distance = std::sqrt(deltaX * deltaX + deltaY * deltaY);

            if (distance <= attackRange && enemySlots[slot]->getProgress() > bestPathProgress)
            {
                bestPathProgress = enemySlots[slot]->getProgress();
                bestTarget = enemySlots[slot];
            }
        }

        return bestTarget;
    }

    void spawnProjectile(float targetX, float targetY, float damageAmount, float projectileSpeed,
        sf::Color projectileColor, float radius = 5.f,
        bool slowShot = false, float slowSeconds = 0.f)
    {
        for (int slot = 0; slot < MAX_PROJECTILES; slot++)
        {
            if (!projectilePool[slot].alive)
            {
                projectilePool[slot].init(x, y, targetX, targetY, damageAmount, projectileSpeed,
                    projectileColor, radius, slowShot, slowSeconds);

                return;
            }
        }
    }

    void advanceProjectiles(float deltaSeconds, Enemy** enemySlots, int slotCount)
    {
        for (int projectileSlot = 0; projectileSlot < MAX_PROJECTILES; projectileSlot++)
        {
            if (!projectilePool[projectileSlot].alive)
            {
                continue;
            }

            projectilePool[projectileSlot].update(deltaSeconds);

            if (projectilePool[projectileSlot].posX < 0.f
                || projectilePool[projectileSlot].posX > 1280.f
                || projectilePool[projectileSlot].posY < 0.f
                || projectilePool[projectileSlot].posY > 720.f)
            {
                projectilePool[projectileSlot].alive = false;

                continue;
            }

            for (int enemySlot = 0; enemySlot < slotCount; enemySlot++)
            {
                if (enemySlots[enemySlot] == nullptr)
                {
                    continue;
                }

                if (!enemySlots[enemySlot]->isActive())
                {
                    continue;
                }

                float deltaX = enemySlots[enemySlot]->getX() - projectilePool[projectileSlot].posX;
                float deltaY = enemySlots[enemySlot]->getY() - projectilePool[projectileSlot].posY;
                float hitDistance = std::sqrt(deltaX * deltaX + deltaY * deltaY);

                if (hitDistance < projectilePool[projectileSlot].hitRadius + 14.f)
                {
                    enemySlots[enemySlot]->takeDamage(projectilePool[projectileSlot].damage);

                    if (projectilePool[projectileSlot].appliesSlow)
                    {
                        enemySlots[enemySlot]->applySlowEffect(projectilePool[projectileSlot].slowDurationSeconds);
                    }

                    projectilePool[projectileSlot].alive = false;

                    break;
                }
            }
        }
    }

    void triggerFireSound();

public:
    Tower(float spawnX, float spawnY, float range, float damage, float fireRate,
        int cost, const std::string& displayName,
        sf::Color bodyColor, sf::Color accentColor)
        : Entity(spawnX, spawnY, displayName)
        , attackRange(range)
        , shotDamage(damage)
        , shotsPerSecond(fireRate)
        , secondsUntilNextShot(0.f)
        , goldCost(cost)
        , upgradeLevel(1)
        , bodyFillColor(bodyColor)
        , accentFillColor(accentColor)
        , owningGame(nullptr)
        , soundIndex(-1)
        , texture(nullptr)
    {}

    virtual ~Tower()
    {}

    void setGame(Game* game, int towerSoundIndex)
    {
        owningGame = game;
        soundIndex = towerSoundIndex;
    }

    void setTexture(const sf::Texture* loadedTexture)
    {
        texture = loadedTexture;
    }

    virtual void attack(Enemy** enemySlots, int slotCount, float deltaSeconds) = 0;

    void update(float deltaSeconds) override
    {
        if (secondsUntilNextShot > 0.f)
        {
            secondsUntilNextShot -= deltaSeconds;
        }
    }

    void render(sf::RenderWindow& window) override
    {
        sf::CircleShape rangeDisk(attackRange);
        rangeDisk.setFillColor(sf::Color(255, 255, 255, 15));
        rangeDisk.setOutlineColor(sf::Color(255, 255, 255, 40));
        rangeDisk.setOutlineThickness(1.f);
        rangeDisk.setOrigin({ attackRange, attackRange });
        rangeDisk.setPosition({ x, y });
        window.draw(rangeDisk);

        if (texture != nullptr)
        {
            sf::Sprite sprite(*texture);
            float scale = 64.f / (float)texture->getSize().x;
            sprite.setScale({ scale, scale });
            sprite.setOrigin({ (float)texture->getSize().x / 2.f,
                               (float)texture->getSize().y / 2.f });
            sprite.setPosition({ x, y });
            window.draw(sprite);
        }
        else
        {
            sf::RectangleShape base({ 64.f, 64.f });
            base.setFillColor(bodyFillColor);
            base.setOutlineColor(sf::Color::Black);
            base.setOutlineThickness(3.f);
            base.setOrigin({ 32.f, 32.f });
            base.setPosition({ x, y });
            window.draw(base);
        }

        for (int slot = 0; slot < MAX_PROJECTILES; slot++)
        {
            if (projectilePool[slot].alive)
            {
                projectilePool[slot].render(window);
            }
        }
    }

    int getCost() const
    {
        return goldCost;
    }

    float getRange() const
    {
        return attackRange;
    }

    float getDamage() const
    {
        return shotDamage;
    }

    float getFireRate() const
    {
        return shotsPerSecond;
    }

    int getLevel() const
    {
        return upgradeLevel;
    }

    bool canUpgrade() const
    {
        return upgradeLevel < 3;
    }

    virtual int getUpgradeCost() const
    {
        return goldCost;
    }

    virtual void upgrade()
    {
        upgradeLevel++;
        shotDamage *= 1.5f;
        attackRange *= 1.15f;
        shotsPerSecond *= 1.2f;
    }

    void drawUpgradePips(sf::RenderWindow& window, sf::Color pipColor)
    {
        for (int pip = 0; pip < upgradeLevel; pip++)
        {
            sf::CircleShape levelDot(4.f);
            levelDot.setFillColor(pipColor);
            levelDot.setPosition({ x - 7.f + pip * 8.f, y + 36.f });
            window.draw(levelDot);
        }
    }
};


class CannonTower : public Tower
{
public:
    CannonTower(float spawnX, float spawnY)
        : Tower(spawnX, spawnY, 130.f, 80.f, 0.7f, 125, "CannonTower",
            sf::Color(100, 100, 120), sf::Color(60, 60, 80))
    {}

    void attack(Enemy** enemySlots, int slotCount, float deltaSeconds) override
    {
        update(deltaSeconds);
        advanceProjectiles(deltaSeconds, enemySlots, slotCount);

        if (secondsUntilNextShot > 0.f)
        {
            return;
        }

        Enemy* target = findFarthestTargetAlongPath(enemySlots, slotCount);

        if (target == nullptr)
        {
            return;
        }

        spawnProjectile(target->getX(), target->getY(), shotDamage, 320.f, sf::Color(50, 50, 60), 8.f);
        secondsUntilNextShot = 1.f / shotsPerSecond;
        triggerFireSound();
    }

    void render(sf::RenderWindow& window) override
    {
        Tower::render(window);

        if (texture == nullptr)
        {
            sf::RectangleShape barrel({ 44.f, 16.f });
            barrel.setFillColor(accentFillColor);
            barrel.setOutlineColor(sf::Color::Black);
            barrel.setOutlineThickness(2.f);
            barrel.setOrigin({ 0.f, 8.f });
            barrel.setPosition({ x, y });
            window.draw(barrel);
        }

        drawUpgradePips(window, sf::Color::Yellow);
    }

    int getUpgradeCost() const override
    {
        return 80;
    }
};


class SniperTower : public Tower
{
public:
    SniperTower(float spawnX, float spawnY)
        : Tower(spawnX, spawnY, 280.f, 120.f, 0.4f, 175, "SniperTower",
            sf::Color(60, 90, 60), sf::Color(30, 60, 30))
    {}

    void attack(Enemy** enemySlots, int slotCount, float deltaSeconds) override
    {
        update(deltaSeconds);
        advanceProjectiles(deltaSeconds, enemySlots, slotCount);

        if (secondsUntilNextShot > 0.f)
        {
            return;
        }

        Enemy* target = findFarthestTargetAlongPath(enemySlots, slotCount);

        if (target == nullptr)
        {
            return;
        }

        spawnProjectile(target->getX(), target->getY(), shotDamage, 600.f, sf::Color(200, 255, 100), 4.f);
        secondsUntilNextShot = 1.f / shotsPerSecond;
        triggerFireSound();
    }

    void render(sf::RenderWindow& window) override
    {
        Tower::render(window);

        if (texture == nullptr)
        {
            sf::RectangleShape barrel({ 60.f, 8.f });
            barrel.setFillColor(accentFillColor);
            barrel.setOutlineColor(sf::Color::Black);
            barrel.setOutlineThickness(2.f);
            barrel.setOrigin({ 0.f, 4.f });
            barrel.setPosition({ x, y });
            window.draw(barrel);
        }

        drawUpgradePips(window, sf::Color::Cyan);
    }

    int getUpgradeCost() const override
    {
        return 100;
    }
};


class MachineGunTower : public Tower
{
public:
    MachineGunTower(float spawnX, float spawnY)
        : Tower(spawnX, spawnY, 110.f, 18.f, 5.f, 150, "MachineGunTower",
            sf::Color(140, 100, 60), sf::Color(100, 70, 40))
    {}

    void attack(Enemy** enemySlots, int slotCount, float deltaSeconds) override
    {
        update(deltaSeconds);
        advanceProjectiles(deltaSeconds, enemySlots, slotCount);

        if (secondsUntilNextShot > 0.f)
        {
            return;
        }

        Enemy* target = findFarthestTargetAlongPath(enemySlots, slotCount);

        if (target == nullptr)
        {
            return;
        }

        for (int spread = -1; spread <= 1; spread++)
        {
            spawnProjectile(
                target->getX() + spread * 5.f,
                target->getY() + spread * 3.f,
                shotDamage,
                450.f,
                sf::Color(255, 200, 50),
                3.5f);
        }

        secondsUntilNextShot = 1.f / shotsPerSecond;
        triggerFireSound();
    }

    void render(sf::RenderWindow& window) override
    {
        Tower::render(window);

        if (texture == nullptr)
        {
            for (int barrelIndex = 0; barrelIndex < 2; barrelIndex++)
            {
                sf::RectangleShape barrel({ 36.f, 6.f });
                barrel.setFillColor(accentFillColor);
                barrel.setOutlineColor(sf::Color::Black);
                barrel.setOutlineThickness(2.f);
                barrel.setOrigin({ 0.f, 3.f });
                barrel.setPosition({ x, y - 8.f + barrelIndex * 16.f });
                window.draw(barrel);
            }
        }

        drawUpgradePips(window, sf::Color(255, 150, 0));
    }

    int getUpgradeCost() const override
    {
        return 90;
    }
};


class SlowTower : public Tower
{
private:
    float pulseTimerSeconds;

public:
    SlowTower(float spawnX, float spawnY)
        : Tower(spawnX, spawnY, 120.f, 5.f, 1.2f, 100, "SlowTower",
            sf::Color(50, 120, 180), sf::Color(30, 90, 140))
        , pulseTimerSeconds(0.f)
    {}

    void attack(Enemy** enemySlots, int slotCount, float deltaSeconds) override
    {
        update(deltaSeconds);
        pulseTimerSeconds -= deltaSeconds;

        if (pulseTimerSeconds <= 0.f && secondsUntilNextShot <= 0.f)
        {
            bool hitAnyone = false;

            for (int enemySlot = 0; enemySlot < slotCount; enemySlot++)
            {
                if (enemySlots[enemySlot] == nullptr)
                {
                    continue;
                }

                if (!enemySlots[enemySlot]->isActive())
                {
                    continue;
                }

                float deltaX = enemySlots[enemySlot]->getX() - x;
                float deltaY = enemySlots[enemySlot]->getY() - y;
                float distance = std::sqrt(deltaX * deltaX + deltaY * deltaY);

                if (distance <= attackRange)
                {
                    enemySlots[enemySlot]->applySlowEffect(2.0f);
                    enemySlots[enemySlot]->takeDamage(shotDamage);
                    hitAnyone = true;
                }
            }

            secondsUntilNextShot = 1.f / shotsPerSecond;
            pulseTimerSeconds = 1.f / shotsPerSecond;

            if (hitAnyone)
            {
                triggerFireSound();
            }
        }
    }

    void render(sf::RenderWindow& window) override
    {
        sf::CircleShape slowZone(attackRange);
        slowZone.setFillColor(sf::Color(50, 120, 255, 20));
        slowZone.setOutlineColor(sf::Color(50, 120, 255, 60));
        slowZone.setOutlineThickness(2.f);
        slowZone.setOrigin({ attackRange, attackRange });
        slowZone.setPosition({ x, y });
        window.draw(slowZone);

        if (texture != nullptr)
        {
            sf::Sprite sprite(*texture);
            float scale = 64.f / (float)texture->getSize().x;
            sprite.setScale({ scale, scale });
            sprite.setOrigin({ (float)texture->getSize().x / 2.f,
                               (float)texture->getSize().y / 2.f });
            sprite.setPosition({ x, y });
            window.draw(sprite);
        }
        else
        {
            sf::RectangleShape base({ 64.f, 64.f });
            base.setFillColor(bodyFillColor);
            base.setOutlineColor(sf::Color::Black);
            base.setOutlineThickness(3.f);
            base.setOrigin({ 32.f, 32.f });
            base.setPosition({ x, y });
            window.draw(base);

            for (int armIndex = 0; armIndex < 4; armIndex++)
            {
                sf::RectangleShape arm({ 28.f, 6.f });
                arm.setFillColor(accentFillColor);
                arm.setOrigin({ 0.f, 3.f });
                arm.setPosition({ x, y });
                arm.setRotation(sf::degrees(armIndex * 45.f));
                window.draw(arm);
            }
        }

        for (int slot = 0; slot < MAX_PROJECTILES; slot++)
        {
            if (projectilePool[slot].alive)
            {
                projectilePool[slot].render(window);
            }
        }

        drawUpgradePips(window, sf::Color(150, 220, 255));
    }

    int getUpgradeCost() const override
    {
        return 70;
    }
};


class LaserTower : public Tower
{
private:
    float beamDrawSecondsLeft;
    float beamTipX;
    float beamTipY;

public:
    LaserTower(float spawnX, float spawnY)
        : Tower(spawnX, spawnY, 200.f, 35.f, 2.5f, 200, "LaserTower",
            sf::Color(180, 50, 50), sf::Color(255, 100, 100))
        , beamDrawSecondsLeft(0.f)
        , beamTipX(0.f)
        , beamTipY(0.f)
    {}

    void attack(Enemy** enemySlots, int slotCount, float deltaSeconds) override
    {
        update(deltaSeconds);
        beamDrawSecondsLeft -= deltaSeconds;

        if (secondsUntilNextShot > 0.f)
        {
            return;
        }

        Enemy* target = findFarthestTargetAlongPath(enemySlots, slotCount);

        if (target == nullptr)
        {
            return;
        }

        beamTipX = target->getX();
        beamTipY = target->getY();

        float aimDeltaX = target->getX() - x;
        float aimDeltaY = target->getY() - y;
        float aimDistance = std::sqrt(aimDeltaX * aimDeltaX + aimDeltaY * aimDeltaY);

        if (aimDistance <= 0.f)
        {
            secondsUntilNextShot = 1.f / shotsPerSecond;
            beamDrawSecondsLeft = 0.15f;
            triggerFireSound();

            return;
        }

        float dirX = aimDeltaX / aimDistance;
        float dirY = aimDeltaY / aimDistance;

        for (int enemySlot = 0; enemySlot < slotCount; enemySlot++)
        {
            if (enemySlots[enemySlot] == nullptr)
            {
                continue;
            }

            if (!enemySlots[enemySlot]->isActive())
            {
                continue;
            }

            float toEnemyX = enemySlots[enemySlot]->getX() - x;
            float toEnemyY = enemySlots[enemySlot]->getY() - y;
            float alongBeam = toEnemyX * dirX + toEnemyY * dirY;

            if (alongBeam < 0.f || alongBeam > aimDistance + 50.f)
            {
                continue;
            }

            float perpX = toEnemyX - alongBeam * dirX;
            float perpY = toEnemyY - alongBeam * dirY;
            float perpDistance = std::sqrt(perpX * perpX + perpY * perpY);

            if (perpDistance < 20.f)
            {
                enemySlots[enemySlot]->takeDamage(shotDamage * deltaSeconds * shotsPerSecond);
            }
        }

        secondsUntilNextShot = 1.f / shotsPerSecond;
        beamDrawSecondsLeft = 0.15f;
        triggerFireSound();
    }

    void render(sf::RenderWindow& window) override
    {
        sf::CircleShape rangeDisk(attackRange);
        rangeDisk.setFillColor(sf::Color(255, 50, 50, 12));
        rangeDisk.setOutlineColor(sf::Color(255, 50, 50, 40));
        rangeDisk.setOutlineThickness(1.f);
        rangeDisk.setOrigin({ attackRange, attackRange });
        rangeDisk.setPosition({ x, y });
        window.draw(rangeDisk);

        if (texture != nullptr)
        {
            sf::Sprite sprite(*texture);
            float scale = 64.f / (float)texture->getSize().x;
            sprite.setScale({ scale, scale });
            sprite.setOrigin({ (float)texture->getSize().x / 2.f,
                               (float)texture->getSize().y / 2.f });
            sprite.setPosition({ x, y });
            window.draw(sprite);
        }
        else
        {
            sf::RectangleShape base({ 64.f, 64.f });
            base.setFillColor(bodyFillColor);
            base.setOutlineColor(sf::Color::Black);
            base.setOutlineThickness(3.f);
            base.setOrigin({ 32.f, 32.f });
            base.setPosition({ x, y });
            window.draw(base);

            sf::CircleShape lens(16.f);
            lens.setFillColor(accentFillColor);
            lens.setOrigin({ 16.f, 16.f });
            lens.setPosition({ x, y });
            window.draw(lens);
        }

        if (beamDrawSecondsLeft > 0.f)
        {
            sf::Vertex beamSegment[] =
            {
                sf::Vertex({ x, y }, sf::Color(255, 80, 80, 220)),
                sf::Vertex({ beamTipX, beamTipY }, sf::Color(255, 200, 200, 80))
            };

            window.draw(beamSegment, 2, sf::PrimitiveType::Lines);
        }

        drawUpgradePips(window, sf::Color(255, 100, 100));
    }

    int getUpgradeCost() const override
    {
        return 120;
    }
};
