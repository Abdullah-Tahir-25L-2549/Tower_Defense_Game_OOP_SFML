#pragma once
#include <string>

static const int MAX_WAVES = 8;
static const int MAX_SPAWNS_WAVE = 20;

struct SpawnInfo
{
    int   enemyType;
    float delayAfterPreviousSeconds;
};

struct WaveData
{
    SpawnInfo spawns[MAX_SPAWNS_WAVE];
    int       spawnCount;
    std::string description;
};

class WaveManager
{
private:
    WaveData waveTable[MAX_WAVES];
    int      numWavesDefined;
    int      activeWaveIndex;
    int      nextSpawnSlot;
    float    timeUntilNextSpawn;
    bool     waveIsRunning;
    bool     everyWaveFinished;

    void addWave(const SpawnInfo* spawnList, int spawnCount, const std::string& desc)
    {
        if (numWavesDefined >= MAX_WAVES)
        {
            return;
        }

        for (int slot = 0; slot < spawnCount; slot++)
        {
            waveTable[numWavesDefined].spawns[slot] = spawnList[slot];
        }

        waveTable[numWavesDefined].spawnCount = spawnCount;
        waveTable[numWavesDefined].description = desc;
        numWavesDefined++;
    }

public:
    WaveManager()
        : numWavesDefined(0)
        , activeWaveIndex(0)
        , nextSpawnSlot(0)
        , timeUntilNextSpawn(0.f)
        , waveIsRunning(false)
        , everyWaveFinished(false)
    {
        SpawnInfo wave1[] =
        {
            { 0, 0.f }, { 0, 1.2f }, { 0, 1.2f }, { 0, 1.0f }, { 0, 1.0f },
            { 0, 1.0f }, { 1, 0.6f }, { 1, 0.6f }
        };
        addWave(wave1, 8, "Wave 1: Scouts");

        SpawnInfo wave2[] =
        {
            { 0, 0.f }, { 1, 0.6f }, { 1, 0.6f }, { 0, 1.0f }, { 1, 0.6f },
            { 0, 1.0f }, { 1, 0.5f }, { 0, 0.8f }, { 1, 0.5f }, { 0, 0.8f }
        };
        addWave(wave2, 10, "Wave 2: Fast Assault");

        SpawnInfo wave3[] =
        {
            { 0, 0.f }, { 0, 0.8f }, { 2, 2.0f }, { 0, 0.8f }, { 2, 2.5f },
            { 1, 0.5f }, { 0, 0.8f }, { 0, 0.8f }, { 1, 0.5f }, { 2, 2.0f }
        };
        addWave(wave3, 10, "Wave 3: Heavy Metal");

        SpawnInfo wave4[] =
        {
            { 3, 0.f }, { 3, 1.0f }, { 0, 0.5f }, { 1, 0.4f }, { 3, 1.0f },
            { 2, 2.0f }, { 3, 0.8f }, { 0, 0.5f }, { 1, 0.4f }, { 0, 0.5f },
            { 3, 1.0f }, { 2, 2.0f }
        };
        addWave(wave4, 12, "Wave 4: Air Raid");

        SpawnInfo wave5[] =
        {
            { 4, 0.f }, { 0, 0.6f }, { 4, 1.5f }, { 1, 0.4f }, { 2, 2.0f },
            { 3, 0.8f }, { 4, 1.2f }, { 0, 0.6f }, { 1, 0.4f }, { 2, 2.0f },
            { 4, 1.5f }, { 0, 0.6f }
        };
        addWave(wave5, 12, "Wave 5: Splitter Chaos");

        SpawnInfo wave6[] =
        {
            { 2, 0.f }, { 2, 1.5f }, { 4, 1.0f }, { 3, 0.8f }, { 1, 0.3f },
            { 2, 2.0f }, { 0, 0.5f }, { 2, 1.5f }, { 4, 1.0f }, { 3, 0.8f },
            { 1, 0.3f }, { 2, 2.0f }, { 0, 0.5f }, { 1, 0.3f }
        };
        addWave(wave6, 14, "Wave 6: Heavy Assault");

        SpawnInfo wave7[] =
        {
            { 1, 0.f }, { 1, 0.3f }, { 1, 0.3f }, { 0, 0.4f }, { 4, 1.0f },
            { 2, 1.5f }, { 1, 0.3f }, { 0, 0.4f }, { 1, 0.3f }, { 1, 0.3f },
            { 4, 1.0f }, { 2, 1.5f }, { 0, 0.4f }, { 1, 0.3f }, { 3, 0.8f }, { 2, 2.0f }
        };
        addWave(wave7, 16, "Wave 7: The Swarm");

        SpawnInfo wave8[] =
        {
            { 2, 0.f }, { 4, 0.8f }, { 2, 2.0f }, { 3, 0.6f }, { 1, 0.3f },
            { 2, 2.0f }, { 4, 1.0f }, { 3, 0.6f }, { 2, 1.5f }, { 1, 0.3f },
            { 4, 0.8f }, { 2, 2.0f }, { 3, 0.6f }, { 1, 0.3f }, { 2, 1.5f },
            { 4, 1.0f }, { 3, 0.6f }, { 2, 2.0f }
        };
        addWave(wave8, 18, "Wave 8: Final Assault");
    }

    void startWave()
    {
        if (activeWaveIndex >= numWavesDefined)
        {
            everyWaveFinished = true;

            return;
        }

        nextSpawnSlot = 0;
        timeUntilNextSpawn = 0.f;
        waveIsRunning = true;
    }

    int update(float deltaSeconds, bool noLivingEnemiesOnField)
    {
        if (!waveIsRunning)
        {
            return -1;
        }

        const WaveData& current = waveTable[activeWaveIndex];

        if (nextSpawnSlot < current.spawnCount)
        {
            timeUntilNextSpawn -= deltaSeconds;

            if (timeUntilNextSpawn <= 0.f)
            {
                int typeToSpawn = current.spawns[nextSpawnSlot].enemyType;
                nextSpawnSlot++;

                if (nextSpawnSlot < current.spawnCount)
                {
                    timeUntilNextSpawn = current.spawns[nextSpawnSlot].delayAfterPreviousSeconds;
                }

                return typeToSpawn;
            }
        }
        else if (noLivingEnemiesOnField)
        {
            waveIsRunning = false;
            activeWaveIndex++;

            if (activeWaveIndex >= numWavesDefined)
            {
                everyWaveFinished = true;
            }
        }

        return -1;
    }

    bool isWaveActive() const
    {
        return waveIsRunning;
    }

    bool isAllDone() const
    {
        return everyWaveFinished;
    }

    int getCurrentWave() const
    {
        return activeWaveIndex + 1;
    }

    int getTotalWaves() const
    {
        return numWavesDefined;
    }

    std::string getDescription() const
    {
        if (activeWaveIndex < numWavesDefined)
        {
            return waveTable[activeWaveIndex].description;
        }

        return "All waves complete!";
    }
};
