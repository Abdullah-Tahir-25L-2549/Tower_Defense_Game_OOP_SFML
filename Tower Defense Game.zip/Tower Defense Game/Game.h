#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <string>
#include <iostream>
#include <cmath>
#include "Enemy.h"
#include "Tower.h"
#include "WaveManager.h"

static const int MAX_TOWERS = 50;
static const int MAX_GRID_ENEMIES = 100;

enum class GameState
{
    MENU,
    PLAYING,
    GAME_OVER,
    WIN
};

class Game
{
private:
    sf::RenderWindow window;
    sf::Font         font;

    sf::Texture texEnemyBasic;
    sf::Texture texEnemyFast;
    sf::Texture texEnemyTank;
    sf::Texture texEnemyFlying;
    sf::Texture texEnemySplitter;
    sf::Texture texTowerCannon;
    sf::Texture texTowerSniper;
    sf::Texture texTowerMG;
    sf::Texture texTowerSlow;
    sf::Texture texTowerLaser;
    bool        textureLoadOk[10];

    sf::SoundBuffer sbCannon;
    sf::SoundBuffer sbSniper;
    sf::SoundBuffer sbMG;
    sf::SoundBuffer sbSlow;
    sf::SoundBuffer sbLaser;
    sf::Sound* sndCannon;
    sf::Sound* sndSniper;
    sf::Sound* sndMG;
    sf::Sound* sndSlow;
    sf::Sound* sndLaser;

    static const int TILE = 40;
    static const int COLS = 32;
    static const int ROWS = 18;

    int grid[18][32];

    Enemy* enemies[MAX_GRID_ENEMIES];
    int    enemyCount;

    Tower* towers[MAX_TOWERS];
    int    towerCount;

    WaveManager waveManager;

    int gold;
    int lives;
    int score;
    int totalKills;

    GameState state;
    int       towerBuildPickIndex;
    Tower* inspectedTower;

    sf::RectangleShape sidebar;

    struct TowerButton
    {
        sf::RectangleShape rect;
        std::string        label;
        std::string        costStr;
        int                cost;
    };
    TowerButton towerButtons[5];

    sf::RectangleShape startWaveBtn;
    sf::RectangleShape upgradeBtn;
    sf::RectangleShape sellBtn;
    sf::RectangleShape buyLivesBtn;

    std::string hudToastMessage;
    float       hudToastSecondsLeft;
    float       pathGlowPhase;

    std::string intToString(int value) const
    {
        if (value == 0)
        {
            return "0";
        }

        std::string digitsReversed;
        bool isNegative = (value < 0);

        if (isNegative)
        {
            value = -value;
        }

        while (value > 0)
        {
            char digit = static_cast<char>('0' + (value % 10));
            digitsReversed = digit + digitsReversed;
            value /= 10;
        }

        if (isNegative)
        {
            return "-" + digitsReversed;
        }

        return digitsReversed;
    }

    const sf::Texture& enemyTextureByIndex(int enemyIndex) const
    {
        switch (enemyIndex)
        {
        case 0:
            return texEnemyBasic;

        case 1:
            return texEnemyFast;

        case 2:
            return texEnemyTank;

        case 3:
            return texEnemyFlying;

        default:
            return texEnemySplitter;
        }
    }

    const sf::Texture& towerTextureByIndex(int towerIndex) const
    {
        switch (towerIndex)
        {
        case 0:
            return texTowerCannon;

        case 1:
            return texTowerSniper;

        case 2:
            return texTowerMG;

        case 3:
            return texTowerSlow;

        default:
            return texTowerLaser;
        }
    }

public:
    Game();
    ~Game();
    void run();

    void playSoundForTower(int towerTypeIndex);

private:
    void buildPath();
    void buildUI();
    void loadAssets();
    void handleEvents();
    void update(float deltaSeconds);
    void render();
    void renderMap();
    void renderHUD();
    void renderMenu();
    void renderGameOver();
    void renderWin();
    void placeTower(int col, int row);
    void spawnEnemy(int enemyTypeIndex);
    void handleMouseClick(float mouseX, float mouseY);
    void resetGame();
    void clearEnemies();
    void clearTowers();
    bool isOnPath(int col, int row) const;
    bool hasTower(int col, int row) const;

    void showFlash(const std::string& message);

    void logGameStart();
    void logKill(const std::string& enemyDisplayName, int goldReward);
    void logLifeLost(int damageToBase, int livesRemaining);
    void logWave(int waveNumberOneBased);
    void logWin();
    void logLoss();

    void drawText(const std::string& text, float posX, float posY,
        unsigned characterSize, sf::Color color = sf::Color::White);
    void drawCentered(const std::string& text, float posY, unsigned characterSize, sf::Color color);
};
