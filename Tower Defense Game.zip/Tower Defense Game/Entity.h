#pragma once
#include <SFML/Graphics.hpp>
#include <string>

class Entity
{
protected:
    float x;
    float y;
    bool  active;
    std::string name;

public:
    Entity(float spawnX, float spawnY, const std::string& entityName)
        : x(spawnX)
        , y(spawnY)
        , active(true)
        , name(entityName)
    {}

    virtual ~Entity()
    {}

    virtual void update(float deltaSeconds) = 0;
    virtual void render(sf::RenderWindow& window) = 0;

    float getX() const
    {
        return x;
    }

    float getY() const
    {
        return y;
    }

    bool isActive() const
    {
        return active;
    }

    void setActive(bool isAlive)
    {
        active = isAlive;
    }

    const std::string& getName() const
    {
        return name;
    }

    bool operator<(const Entity& other) const
    {
        float thisDistSq = x * x + y * y;
        float otherDistSq = other.x * other.x + other.y * other.y;

        return thisDistSq < otherDistSq;
    }
};
